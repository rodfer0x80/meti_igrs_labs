#!/usr/bin/env sh

docker-compose up --build -d
