#!/bin/bash

# Get things rolling for pcscf

# Configurating
cd /opt/OpenIMSCore/ser_ims/cfg
echo 'pwd'
/opt/OpenIMSCore/ser_ims/cfg/configurator.sh
cp /opt/OpenIMSCore/ser_ims/cfg/*.cfg /opt/OpenIMSCore/.
cp /opt/OpenIMSCore/ser_ims/cfg/*.xml /opt/OpenIMSCore/.

wait 5
# Launching the icscf service
cd /opt/OpenIMSCore/
/opt/OpenIMSCore/ser_ims/cfg/pcscf.sh
while true; do
    echo "This will run forever until you stop it."
    sleep 1  # Pause for 1 second to avoid high CPU usage
done