#!/bin/bash

# Get things rolling for icscf

# Configurating
cd /opt/OpenIMSCore/ser_ims/cfg
echo 'pwd'
/opt/OpenIMSCore/ser_ims/cfg/configurator.sh
cp /opt/OpenIMSCore/ser_ims/cfg/*.cfg /opt/OpenIMSCore/.
cp /opt/OpenIMSCore/ser_ims/cfg/*.xml /opt/OpenIMSCore/.

# Launching and configuring the mysql
/usr/bin/mysqld_safe &
sleep 10
cd /opt/OpenIMSCore/
mysql -u root < /opt/OpenIMSCore/ser_ims/cfg/icscf.sql
mysql -u root < /opt/OpenIMSCore/ser_ims/cfg/persist_my.sql
wait 5
# Launching the icscf service
cd /opt/OpenIMSCore/
/opt/OpenIMSCore/ser_ims/cfg/icscf.sh
while true; do
    echo "This will run forever until you stop it."
    sleep 1  # Pause for 1 second to avoid high CPU usage
done