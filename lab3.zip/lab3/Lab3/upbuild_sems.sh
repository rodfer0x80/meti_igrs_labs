#!/usr/bin/env sh 

xhost +local:
docker-compose -f compose_lab3_sems.yaml up -d --build
