#!/usr/bin/env sh 

docker-compose -f compose_lab3_sems.yaml down -v
xhost -local:
