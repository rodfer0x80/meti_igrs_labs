#!/usr/bin/env sh 

xhost +local:
docker-compose -f compose_lab3_b2bua.yaml up -d --build
