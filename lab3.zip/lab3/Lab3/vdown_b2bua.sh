#!/usr/bin/env sh 

docker-compose -f compose_lab3_b2bua.yaml down -v
xhost -local:
