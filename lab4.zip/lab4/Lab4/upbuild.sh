#!/usr/bin/env sh 

xhost +local:
docker-compose -f compose_lab4.yaml up -d --build
