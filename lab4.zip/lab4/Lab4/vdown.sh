#!/usr/bin/env sh 

docker-compose -f compose_lab4.yaml down -v
xhost -local:
