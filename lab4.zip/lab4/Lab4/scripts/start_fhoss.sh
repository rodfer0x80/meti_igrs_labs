#!/bin/bash

# Get things rolling for FoHSS
# Changing the FQQNs
sed -i "s|__REALM_FQQN_|$__ENV_FQQN_|g" /opt/OpenIMSCore//FHoSS/deploy/DiameterPeerHSS.xml
sed -i "s|__REALM_FQQN_|$__ENV_FQQN_|g" /opt/OpenIMSCore/FHoSS/deploy/userdata.sql
sed -i "s|__REALM2_FQQN_|$__ENV2_FQQN_|g" /opt/OpenIMSCore/FHoSS/deploy/userdata.sql

# Launching and configuring the mysql
/usr/bin/mysqld_safe &
sleep 10
mysql -u root < /opt/OpenIMSCore/FHoSS/deploy/hss_db.sql
mysql -u root < /opt/OpenIMSCore/FHoSS/deploy/userdata.sql
sleep 5
# Launching the hss service
cd /opt/OpenIMSCore/FHoSS/deploy
./startup.sh
