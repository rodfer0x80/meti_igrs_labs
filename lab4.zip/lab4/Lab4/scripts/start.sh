#!/usr/bin/env sh

CWD="/opt/OpenIMSCore/scripts"
"${CWD}/start_icscf.sh" &
"${CWD}/start_pcscf.sh" &
"${CWD}/start_scscf.sh" &
"${CWD}/start_fhoss.sh"
