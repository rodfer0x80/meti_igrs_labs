#!/bin/sh
cp -R /tmp/twinkle/* /root/.twinkle/.
exec /usr/local/bin/twinkle