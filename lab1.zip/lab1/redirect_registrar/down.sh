#!/usr/bin/env sh

docker-compose down -v 
